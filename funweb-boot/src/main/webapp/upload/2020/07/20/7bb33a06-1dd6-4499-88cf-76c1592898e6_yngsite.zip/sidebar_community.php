  		<aside>
  			<h3><div>커뮤니티</div></h3>
  			<ul>
  				<li><a href="#">포토캘러리</a></li>
  				<li><a href="#">제품토론장</a></li>
  				<li><a href="#">자유게시판 </a></li>
  				<li><a href="#">유저사용기 </a></li>
  			</ul>
  		</aside>

