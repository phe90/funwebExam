  		<aside>
  			<h3><div>고객지원센터</div></h3>
  			<ul>
  				<li><a href="#">고객상담게시판</a></li>
  				<li><a href="#">공지사항</a></li>
  				<li><a href="#">새로운 뉴스 </a></li>
  			</ul>
  		</aside>

