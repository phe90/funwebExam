  		<aside>
  			<h3><div>제품정보</div></h3>
  			<ul>
  				<li><a href="#">스마트 폰</a></li>
  				<li><a href="#">디지털 카메라</a></li>
  				<li><a href="#">대형가전제품 </a></li>
  				<li><a href="#">소형가전 제품 </a></li>
  			</ul>
  		</aside>

