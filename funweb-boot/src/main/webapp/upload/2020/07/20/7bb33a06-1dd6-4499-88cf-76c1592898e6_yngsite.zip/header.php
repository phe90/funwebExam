<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>YNG에 오신 여러분을 환영합니다.</title>
    <link href="css/reset5.css" rel="stylesheet" type="text/css">
    <link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css"> 
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
</head>
<body>
	<div id="wrap">
		<header>
			<div id="logo"><a href="./">YNG Corp.</a></div>
			<div id="hlink">
				<ul>
					<li><a href="#">로그인</a></li>
					<li><a href="#">회원가입</a></li>
				</ul>
			</div>
           
			<nav>
				<ul>
					<li class="n1"><a href="company.html">회사소개</a></li>
					<li class="n2"><a href="product.html">제품정보</a></li>
					<li class="n3"><a href="community.html">커뮤니티</a></li>
					<li class="n4"><a href="customer.html">고객지원</a></li>
				</ul>
			</nav>
		</header>
   